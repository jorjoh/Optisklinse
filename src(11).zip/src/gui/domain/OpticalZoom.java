package gui.domain;


import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class OpticalZoom extends MoveableComponent implements Observer {

	//private Background background;
	private Image image;
	private Rectangle r = new Rectangle(100, 100, 200, 200);
	private int resize;
	int width = 400;
	int height = 220;
	final int WIDTH = 400;
	final int HEIGHT = 400;
	int nyBredde = WIDTH * (resize / 100);
	int nyHøyde = HEIGHT * (resize / 100);
	int denHalveNyeBredde = nyBredde/2;
	int denHalveNyeHøyde = nyHøyde/2;



	public OpticalZoom(Background background) {
		image = background.getimage();
		//this.background = background;
		setSize(width, height);
		setVisible(true);

	}

	public void paint(Graphics g) {
		g.drawImage(image, 0, 0,WIDTH, HEIGHT, r.x, r.y, r.x + recalculate(WIDTH), r.y + recalculate(HEIGHT), null);

		System.out.println("r.x" + r.x);
		r = new Rectangle((getX()+ (nyBredde) - (denHalveNyeBredde)), (getY() + (nyHøyde) - (denHalveNyeHøyde)), getWidth(), getHeight());
		System.out.println("WIDTH: " + WIDTH);
		System.out.println("HEIGHT: " + HEIGHT);
		System.out.println("nyBredde: " + nyBredde);
		System.out.println("nyHøyde: " + nyHøyde);
		System.out.println("denHalveNyeBredde: " + denHalveNyeBredde);
		System.out.println("denHalveNyeHøyde: " + denHalveNyeHøyde);
		//System.out.println("Rectangle bredde" + getWidth());
		//System.out.println("Rectangle høyde" + getHeight());
		System.out.println("Resize value is: " + resize);

		g.setColor(Color.RED);
		g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);

	}

	private int recalculate(int q) {
		double d = (q * resize / 100);
		//System.out.println("Verdien q " + q);
		System.out.println("Verdien d " + d);
		return (int) Math.round(d);

	}

	@Override
	public void update(Observable o, Object arg) {
		resize = (Integer) arg;
		System.out.println("update() called, count is " + arg);
		repaint();

	}

}
