package gui;

import gui.domain.Domainview;
import gui.domain.ZoomController;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;

public class Centerpane extends JPanel {

	static Domainview demopanel;


	public Centerpane() {
		setLayout(new BorderLayout());
		//add(opticalZoompanel = new OpticalZoom());
		add(demopanel = new Domainview());


	}

	public void selectGlassColor() {
		demopanel.selectGlassColor();
	}

	public void selectShape() {
		demopanel.selectShape();
	}

	public Dimension getTheSize() {
		return demopanel.getTheSize();
	}

	public void enlargeFrame() {
		demopanel.enlargeFrame();
	}

	public void adjustZoomLevel() {
		demopanel.adjustAoomLevel();
	}

}
