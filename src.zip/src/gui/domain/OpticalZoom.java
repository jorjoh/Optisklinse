package gui.domain;


import javax.swing.*;
import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class OpticalZoom extends JFrame implements Observer{

	//private Background background;
	private Image image;
	private  Rectangle r = null;
	int resize = 100;

	public OpticalZoom(Background background){
		setTitle("OpticalZoom");
		image = background.getimage();
		//this.background = background;
		int width = 400;
		int height = 220;
		setSize(width, height);
		setVisible(true);

	}


	public void paint(Graphics g){
		g.drawImage(image,0,0,getWidth(),getHeight(), r.x,r.y,r.x+recalculate(getWidth()),r.y+recalculate(getHeight()),null);
	}

	private int recalculate(int q) {
		double d = q*resize/100;
		return (int)Math.round(d);
	}


	@Override
	public void update(Observable o, Object arg) {
		r = (Rectangle) arg;
		repaint();


	}

}
