package controller;


import java.awt.*;
import java.util.Observable;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class WindowObservable extends Observable {

	public void setValue(Rectangle r){
		setChanged();
		notifyObservers(r);
		clearChanged();
	}
	public void setValueForZoom(int i){
		setChanged();
		notifyObservers(i);
		System.out.println("Verdien i windowObservable" + i);
		clearChanged();

		//Skjønner ikke hvordan jeg skal få verdien fra denne klassen og inn i OpticalZoom.
		//Update-metoden kan jo ikke ta begge parameterene på likt
	}


}
