package gui.domain;


import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class OpticalZoom extends MoveableComponent implements Observer {

	//private Background background;
	private Image image;
	private Rectangle r = new Rectangle(100, 100, 200, 200);
	private int resize = 0;


	public OpticalZoom(Background background) {
		image = background.getimage();
		//this.background = background;
		int width = 400;
		int height = 220;
		setSize(width, height);
		setVisible(true);

	}

	public void paint(Graphics g) {
		g.drawImage(image, 0, 0, getWidth(), getHeight(), r.x, r.y, r.x + recalculate(getWidth()), r.y + recalculate(getHeight()), null);
		r = new Rectangle(getX(), getY(), getHeight(), getWidth());

		System.out.println("Resize value is: " + resize);
		g.setColor(Color.RED);
		g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
	}

	private int recalculate(int q) {
		double d = q * resize / 100;

		System.out.println("Verdien q " + q);
		System.out.println("Verdien d " + d);

		return (int) Math.round(d);

	}


	@Override
	public void update(Observable o, Object arg) {
		resize = (Integer) arg;
		System.out.println("update() called, count is " + arg);

	}

}
