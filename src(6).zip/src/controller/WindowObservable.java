package controller;

import java.util.Observable;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class WindowObservable extends Observable {

	public void setValue(Integer i) {
		setChanged();
		notifyObservers(i);
		clearChanged();
		System.out.println("Interger vaule in WindowObservable is: " + i);
	}

}
