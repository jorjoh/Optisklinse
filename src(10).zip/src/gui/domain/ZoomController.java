package gui.domain;

import controller.WindowObservable;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class ZoomController extends JFrame {
	int min = 10;
	int max = 200;
	int value = 100;

	int i = 100;
	JFrame zoomingArea = new JFrame();
	JSlider slider = new JSlider(min,max,value);
	JLabel magnificationValue = new JLabel("Current magnification is: " + slider.getValue() + "x");

	JButton pluss = new JButton();
	JButton minus = new JButton();


	WindowObservable windowObservable = new WindowObservable();

	public ZoomController(OpticalZoom opticalZoom) {

		zoomingArea.setTitle("ZoomController");
		zoomingArea.setSize(500, 150);
		zoomingArea.setLocation(0, 200);
		zoomingArea.setLayout(new BorderLayout());

		zoomingArea.add(slider, BorderLayout.SOUTH);
		zoomingArea.add(magnificationValue, BorderLayout.CENTER);
		zoomingArea.setVisible(true);

		windowObservable.addObserver(opticalZoom);

		magnificationValue.setFont(new Font("Serif", Font.BOLD, 20));

		pluss.setText("+");
		minus.setText("-");

		zoomingArea.add(pluss, BorderLayout.EAST);
		zoomingArea.add(minus, BorderLayout.WEST);

		pluss.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				i-=10;
				windowObservable.setValue(i);
				magnificationValue.setText("Current magnification is: " + i + "x");
				if(i == 0){
					System.out.println("VERDIEN ER 0");
					pluss.setEnabled(false);

				}
				else {
					//pluss.setEnabled(true);
				}
			}
		});
		minus.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				i+=10;
				windowObservable.setValue(i);
				magnificationValue.setText("Current magnification is: " + i + "x");
				if(i != 0){
					pluss.setEnabled(true);

				}
			}
		});


		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(1);
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);
		//slider.setInverted(true);

		slider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				System.out.println("Slider sin verdi er: " + slider.getValue());
				windowObservable.setValue(slider.getValue());
				magnificationValue.setText("Current magnification is: " + slider.getValue() + "x");
			}
		});

	}
}
