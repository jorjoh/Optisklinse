package gui.domain;

import controller.WindowObservable;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class ZoomController extends JFrame implements Observer{

	int orientation = SwingConstants.HORIZONTAL;
	int min = 50;
	int max = 200;
	int value = 100;
	JPanel zoomingArea = new JPanel();

	JSlider slider = new JSlider();

	WindowObservable windowObservable = new WindowObservable();
	int i = 0;

	public ZoomController(final OpticalZoom opticalZoom){
		setTitle("ZoomController");
		setLayout(new BorderLayout());
		add(zoomingArea, BorderLayout.NORTH);

		zoomingArea.add(slider);
		slider.getValue();

		windowObservable.setValueForZoom(slider.getValue());
		slider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				System.out.println("Slider sin verdi er: " + slider.getValue());
				opticalZoom.resize = slider.getValue();
			}
		});
		//System.out.println("slider sin verdi er " + slider.getValue());

		setVisible(true);
		setSize(300,150);
		setLocation(0,300);
		setVisible(true);
	}

	@Override
	public void update(Observable o, Object arg) {
		i  = (Integer) arg;
		
	}
}
