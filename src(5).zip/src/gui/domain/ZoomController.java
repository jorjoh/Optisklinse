package gui.domain;

import controller.WindowObservable;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class ZoomController extends JFrame {
	int min = 0;
	int max = 200;
	int value = 0;

	JFrame zoomingArea = new JFrame();
	JSlider slider = new JSlider(min, max, value);
	JLabel magnificationValue = new JLabel("Current magnification is: " + slider.getValue() + "x");

	WindowObservable windowObservable = new WindowObservable();

	public ZoomController(OpticalZoom opticalZoom) {

		setTitle("ZoomController");
		zoomingArea.setSize(500, 150);
		zoomingArea.setLocation(0, 200);
		zoomingArea.setLayout(new BorderLayout());

		zoomingArea.add(slider, BorderLayout.SOUTH);
		zoomingArea.add(magnificationValue, BorderLayout.CENTER);
		zoomingArea.setVisible(true);

		windowObservable.addObserver(opticalZoom);

		magnificationValue.setFont(new Font("Serif", Font.BOLD, 20));

		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(1);
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);

		slider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				System.out.println("Slider sin verdi er: " + slider.getValue());
				windowObservable.setValue(slider.getValue());
				magnificationValue.setText("Current magnification is: " + slider.getValue() + "x");
			}
		});

	}
}
