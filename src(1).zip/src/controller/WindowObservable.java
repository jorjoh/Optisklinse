package controller;


import java.awt.*;
import java.util.Observable;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class WindowObservable extends Observable {

	public void setValue(Rectangle r){
		setChanged();
		notifyObservers(r);
		clearChanged();
	}
	public void setValueForZoom(int i){
		setChanged();
		notifyObservers(i);
		System.out.println("Verdien i windowObservable" + i);
		clearChanged();
	// Skjønner ikke hvordan jeg skal få sendt denne verdien inn til OpticalZoom via update-metoden.
	}

	public void valueForZoom(int i){
		Controller.valueForZoom(i);

	}
}
