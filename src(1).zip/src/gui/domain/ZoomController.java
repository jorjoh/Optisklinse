package gui.domain;

import controller.WindowObservable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class ZoomController extends JFrame implements Observer {

	JPanel zoomingArea = new JPanel();
	JButton pluss = new JButton("Increase Zoom");
	JButton minus = new JButton("Decrease Zoom");
	int i = 100;

	WindowObservable windowObservable = new WindowObservable();

	public ZoomController(){
		setTitle("ZoomController");
		setLayout(new BorderLayout());
		add(zoomingArea, BorderLayout.NORTH);
		zoomingArea.add(pluss);
		zoomingArea.add(minus);
		setVisible(true);


		setSize(300,150);
		setLocation(0,300);
		setVisible(true);

		pluss.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				i-=10;
				System.out.println(i);
				//windowObservable.setValueForZoom(i);
				windowObservable.valueForZoom(i);
			}
		});
		minus.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				i+=10;
				System.out.println(i);
				//windowObservable.setValueForZoom(i);
				windowObservable.valueForZoom(i);
			}
		});

	}



	@Override
	public void update(Observable o, Object arg) {



	}
}
