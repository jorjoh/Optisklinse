package gui.domain;


import controller.WindowObservable;

import javax.swing.*;
import java.awt.*;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Observable;
import java.util.Observer;

import static java.lang.Integer.parseInt;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class OpticalZoom extends JFrame implements Observer{

	//private Background background;
	private Image image;
	private  Rectangle r = null;
	static int resize = 200;


	public OpticalZoom(Background background){
		setTitle("OpticalZoom");
		image = background.getimage();
		//this.background = background;
		int width = 400;
		int height = 220;
		setSize(width, height);
		setVisible(true);

		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("ZoomController sin verdi er " + resize);

			}
		});

	}

	public void paint(Graphics g){
		g.drawImage(image,0,0,getWidth(),getHeight(), r.x,r.y,r.x+recalculate(resize),r.y+recalculate(resize),null);

	}

	private int recalculate(int q) {
		double d = q*resize/100;
		return (int)Math.round(d);

	}


	@Override
	public void update(Observable o, Object arg) {
		r = (Rectangle) arg;

		repaint();

	}


	public static void valueForZoom(int i) {
		resize = i;
		System.out.println(i);
	}
}
