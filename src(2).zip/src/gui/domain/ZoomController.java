package gui.domain;

import controller.WindowObservable;

import javax.swing.*;
import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class ZoomController extends JFrame {

	JPanel zoomingArea = new JPanel();

	JSlider slider = new JSlider();
	int i = 100;

	WindowObservable windowObservable = new WindowObservable();

	public ZoomController(){
		setTitle("ZoomController");
		setLayout(new BorderLayout());
		add(zoomingArea, BorderLayout.NORTH);
		slider.setOrientation(SwingConstants.HORIZONTAL);

		zoomingArea.add(slider);
		setVisible(true);

		setSize(300,150);
		setLocation(0,300);
		setVisible(true);

		//System.out.print(slider);


	}

}
