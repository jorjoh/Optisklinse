package controller;

import easylib.controller.SuperAction;
import easylib.controller.Usecase;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class AZoom extends SuperAction {

	AZoom(Usecase usecase) {
		super(usecase);
		putValue(Action.SHORT_DESCRIPTION, "Velg forstørrelse");
		putValue(Action.LONG_DESCRIPTION, "Velg forstørrelse på bildet");
	}

	public void actionPerformed(ActionEvent e) {
		Controller.enlargeFrame();
		Controller.adjustZoomLevel();
	}
}
