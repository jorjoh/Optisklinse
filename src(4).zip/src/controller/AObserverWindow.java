package controller;

import easylib.controller.SuperAction;
import easylib.controller.Usecase;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class AObserverWindow extends SuperAction {

		AObserverWindow(Usecase usecase) {
			super(usecase);
			putValue(Action.SHORT_DESCRIPTION, "Lag vindu");
			putValue(Action.LONG_DESCRIPTION, "Lag et helt nytt observervindu");
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			Controller.enlargeFrame();
		}


}
