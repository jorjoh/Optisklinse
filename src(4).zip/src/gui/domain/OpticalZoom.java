package gui.domain;


import controller.WindowObservable;

import javax.swing.*;
import java.awt.*;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Observable;
import java.util.Observer;

import static java.lang.Integer.parseInt;

/**
 * Created by Jørgen Johansen on 17.02.2016.
 */
public class OpticalZoom extends MoveableComponent implements Observer{

	//private Background background;
	WindowObservable windowObservable = new WindowObservable();
	private Image image;
	private  Rectangle r = new Rectangle(100,100,200,200);
	int resize = 200;

	public OpticalZoom(Background background){
		image = background.getimage();
		//this.background = background;
		int width = 400;
		int height = 220;
		setSize(width, height);
		setVisible(true);

		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("ZoomController sin verdi er " + resize);

			}
		});

	}

	public void paint(Graphics g){
		g.drawImage(image,0,0,getWidth(),getHeight(), r.x,r.y,r.x+recalculate(resize),r.y+recalculate(resize),null);
		r = new Rectangle(getX(), getY(), getHeight(), getWidth());
		windowObservable.setValue(r);
		System.out.println("Resize: " + resize);
		g.setColor(Color.RED);
		g.drawRect(0,0,getWidth()-1,getHeight()-1);
	}

	private int recalculate(int q) {
		double d = q*resize/100;
		return (int)Math.round(d);

	}

	@Override
	public void update(Observable o, Object arg) {
		r  = (Rectangle) arg;
		repaint();

	}

}
